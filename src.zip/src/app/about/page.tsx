// src/app/about/page.tsx

import About from "app/_components/About";

export default function AboutPage() {
  return <About />
}
