// src/app/skills/page.tsx

import Skills from "app/_components/Skills";

export default function SkillsPage() {
  return <Skills />
}
